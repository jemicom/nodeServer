const http = require("http");
const PORT = 3000;
const fs = require("fs");
const fsPromises = fs.promises;
const path = require("path");
const server = http.createServer();

server.on("request", async (req, res) => {
  let filePath = path.join(
    __dirname,
    "views",
    req.url === "/" ? "index.html" : req.url
  );
  // let filePath = path.join(__dirname, "views", req.url === '/' ? 'index.html' : req.url+".html");

  let extname = path.extname(filePath);
  let contentType = "text/html; charset=utf-8";

  switch (extname) {
    case ".js":
      contentType = "text/javascript";
      break;
    case ".html":
      contentType = "text/html";
      break;
    case ".css":
      contentType = "text/css";
      break;
    case ".json":
      contentType = "application/json";
      break;
    case ".png":
      contentType = "image/png";
      break;
    case ".jpg":
      contentType = "image/jpg";
      break;
    case ".jepg":
      contentType = "image/jepg";
      break;
    case ".gif":
      contentType = "image/gif";
      break;
  }

  // localhost:3000/
  // localhost:3000/create
  let content; // 요청된 파일을 읽어서 저장하기 위한 변수
  try {
    res.writeHead(200, { "Content-Type": contentType });

    if (req.url === "/" && req.method === "GET") {
      content = await fs.readFileSync(
        path.join(__dirname, "views", "index.html")
      );
      res.end(content);

      ///////////////////////////////////////////////////////////////////
    } else if (req.url.includes("css") && req.method === "GET") {
      content = await fs.readFileSync(
        path.join(__dirname, "views", "styles", "index.css")
      );
      res.end(content);

      ///////////////////////////////////////////////////////////////////
    } else if (
      extname.includes("jpg") ||
      extname.includes("png") ||
      (extname.includes("gif") && req.method === "GET")
    ) {
      content = await fs.readFileSync(filePath);
      // 이미지 확장자일때는 설정된 경로에서 읽어와 응답
      res.end(content);
    }

    console.log(req.method, filePath);
  } catch (err) {
    console.log(err);
  }
});

server.listen(PORT, () => {
  console.log("server start", PORT);
});
